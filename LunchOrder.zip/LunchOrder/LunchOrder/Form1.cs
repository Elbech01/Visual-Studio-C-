using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LunchOrder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ClearTotals()
        {
            lblOrderTotal.Text = "";
            lblSalesTax.Text = "";
            lblSubtotal.Text = "";
        }
        private void ClearAddOns()
        {
            chkAddOn1.Checked = false;
            chkAddOn2.Checked = false;
            chkAddOn3.Checked = false;
        }

        private void radHamburger_CheckedChanged(object sender, EventArgs e)
        {
            if (radHamburger.Checked)
            {
                gbxAddOns.Text = "Add-on Items ($.75/each)";
                chkAddOn1.Text = "Lettuce, tomato, and onions";
                chkAddOn2.Text = "Ketchup, mustard, and mayo";
                chkAddOn3.Text = "French fries";
            }
            else if (radPizza.Checked)
            {
                gbxAddOns.Text = "Add-on Items ($.50/each)";
                chkAddOn1.Text = "Pepperoni";
                chkAddOn2.Text = "Sausage";
                chkAddOn3.Text = "Olives";
            }
            else
            {
                gbxAddOns.Text = "Add-on Items ($.25/each)";
                chkAddOn1.Text = "Croutons";
                chkAddOn2.Text = "Bacon bits";
                chkAddOn3.Text = "Bread sticks";
            }
            ClearAddOns();
            ClearTotals();
        }

        private void radPizza_CheckedChanged(object sender, EventArgs e)
        {
            if (radHamburger.Checked)
            {
                gbxAddOns.Text = "Add-on Items ($.75/each)";
                chkAddOn1.Text = "Lettuce, tomato, and onions";
                chkAddOn2.Text = "Ketchup, mustard, and mayo";
                chkAddOn3.Text = "French fries";
            }
            else if (radPizza.Checked)
            {
                gbxAddOns.Text = "Add-on Items ($.50/each)";
                chkAddOn1.Text = "Pepperoni";
                chkAddOn2.Text = "Sausage";
                chkAddOn3.Text = "Olives";
            }
            else
            {
                gbxAddOns.Text = "Add-on Items ($.25/each)";
                chkAddOn1.Text = "Croutons";
                chkAddOn2.Text = "Bacon bits";
                chkAddOn3.Text = "Bread sticks";
            }
            ClearAddOns();
            ClearTotals();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            decimal addons = 0m;
            decimal price;
            decimal subtotal;
            decimal salesTax = .0775m;
            decimal salesTaxTotal;
            decimal orderTotal;
            if (radHamburger.Checked) 
            { 
                if (chkAddOn1.Checked) { addons += .75m; }
                if (chkAddOn2.Checked) { addons += .75m; }
                if (chkAddOn3.Checked) { addons += .75m; }
                price = 6.95m;
            }
            else if (radPizza.Checked)
            {
                if (chkAddOn1.Checked) { addons += .5m; }
                if (chkAddOn2.Checked) { addons += .5m; }
                if (chkAddOn3.Checked) { addons += .5m; }
                price = 5.95m;
            }
            else
            {
                if (chkAddOn1.Checked) { addons += .25m; }
                if (chkAddOn2.Checked) { addons += .25m; }
                if (chkAddOn3.Checked) { addons += .25m; }
                price = 4.95m;
            }
            subtotal = price + addons;
            salesTaxTotal = subtotal * salesTax;
            orderTotal = subtotal + salesTaxTotal;
            lblSubtotal.Text = String.Format("${0:#,##0.00}", subtotal);
            lblSalesTax.Text = String.Format("${0:#,##0.00}", salesTaxTotal);
            lblOrderTotal.Text = String.Format("${0:#,##0.00}", orderTotal);

        }

        private void chkAddOn1_CheckedChanged(object sender, EventArgs e)
        {
            ClearTotals();
        }

        private void chkAddOn2_CheckedChanged(object sender, EventArgs e)
        {
            ClearTotals();
        }

        private void chkAddOn3_CheckedChanged(object sender, EventArgs e)
        {
            ClearTotals();
        }
    }
}