﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7
{


    public class Book
    {
        private string isbn;
        private string title;
        private string genre;

        public Book() { }

        public Book(string ISBN, string title, string genre)
        {
            this.isbn = ISBN;
            this.title = title;
            this.genre = genre;
        }

        public string ISBN
        {
            get
            {
                return isbn;
            }
            set
            {
                isbn = value;
            }
        }
        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }
        public string Genre
        {
            get
            {
                return genre;
            }
            set
            {
                genre = value;
            }
        }

        public override string ToString()
        {
            return isbn + "   " + title + "   " + genre;
        }
    }
}
