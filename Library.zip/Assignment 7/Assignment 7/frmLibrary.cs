﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_7
{
    public partial class frmLibrary : Form
    {
        public frmLibrary()
        {
            InitializeComponent();
            lstBooks.Items.Add("97807763621   Fellowship OTR   Fiction");
            lstBooks.Items.Add("97807763622   The Two Towers   Fiction");
            lstBooks.Items.Add("41251531   Murach Visual C#   Non-Fiction");

        }

        private Book book;


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DisplayBook()
        {
            if (!lstBooks.Items.Contains(book.ToString()))
            {
                lstBooks.Items.Add(book.ToString());
                lstOutput.Items.Add("The book with ISBN " + book.ISBN + " was successfully added.");
            }
            else
            {
                MessageBox.Show("The book with ISBN " + book.ISBN + " has already been added to the master list of books.", "Error");
            }
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAddBook addBookForm = new frmAddBook();
            addBookForm.addBook = true;
            DialogResult result = addBookForm.ShowDialog();
            if (result == DialogResult.OK)
            {
                book = addBookForm.book;
                this.DisplayBook();
            }
        }
    }
}
