﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_7
{
    public partial class frmAddBook : Form
    {
        public frmAddBook()
        {
            InitializeComponent();
        }

        public bool addBook;
        public Book book;

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                if (addBook)
                {
                    book = new Book();
                    this.PutBookData(book);
                    try
                    { 
                        DialogResult = DialogResult.OK;
                    }
                    catch (Exception ex)
                    {

                        throw ex;
                    }
                }
            }
        }
        private void PutBookData(Book book)
        {
            book.ISBN = txtISBN.Text;
            book.Title = txtTitle.Text;
            if (radBiography.Checked)
            {
                book.Genre = "Biography";
            }
            else if (radFiction.Checked)
            {
                book.Genre = "Fiction";
            }
            else if (radNon.Checked)
            {
                book.Genre = "Non-Fiction";
            }
            else if (radMystery.Checked)
            {
                book.Genre = "Mystery";
            }
            
        }

        public static bool IsPresent(TextBox textbox)
        {
            if (textbox.Text == "")
            {
                MessageBox.Show(textbox.Tag + " is a required field.", "Error");
                textbox.Focus();
                return false;
            }
            return true;
        }
        private bool IsValidData()
        {
            return IsPresent(txtISBN) &&
                   IsPresent(txtTitle);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
