﻿namespace Assignment_7
{
    partial class frmAddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblISBN = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblGenre = new System.Windows.Forms.Label();
            this.btnAccept = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.grpGenre = new System.Windows.Forms.GroupBox();
            this.radBiography = new System.Windows.Forms.RadioButton();
            this.radMystery = new System.Windows.Forms.RadioButton();
            this.radNon = new System.Windows.Forms.RadioButton();
            this.radFiction = new System.Windows.Forms.RadioButton();
            this.grpGenre.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Location = new System.Drawing.Point(23, 13);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(35, 13);
            this.lblISBN.TabIndex = 0;
            this.lblISBN.Text = "ISBN:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(23, 43);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(30, 13);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Title:";
            // 
            // lblGenre
            // 
            this.lblGenre.AutoSize = true;
            this.lblGenre.Location = new System.Drawing.Point(23, 71);
            this.lblGenre.Name = "lblGenre";
            this.lblGenre.Size = new System.Drawing.Size(39, 13);
            this.lblGenre.TabIndex = 2;
            this.lblGenre.Text = "Genre:";
            // 
            // btnAccept
            // 
            this.btnAccept.Location = new System.Drawing.Point(26, 150);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(75, 23);
            this.btnAccept.TabIndex = 3;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(315, 150);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(68, 10);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(150, 20);
            this.txtISBN.TabIndex = 5;
            this.txtISBN.Tag = "ISBN";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(68, 40);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(322, 20);
            this.txtTitle.TabIndex = 6;
            this.txtTitle.Tag = "Title";
            // 
            // grpGenre
            // 
            this.grpGenre.Controls.Add(this.radBiography);
            this.grpGenre.Controls.Add(this.radMystery);
            this.grpGenre.Controls.Add(this.radNon);
            this.grpGenre.Controls.Add(this.radFiction);
            this.grpGenre.Location = new System.Drawing.Point(69, 71);
            this.grpGenre.Name = "grpGenre";
            this.grpGenre.Size = new System.Drawing.Size(321, 73);
            this.grpGenre.TabIndex = 7;
            this.grpGenre.TabStop = false;
            // 
            // radBiography
            // 
            this.radBiography.AutoSize = true;
            this.radBiography.Location = new System.Drawing.Point(146, 42);
            this.radBiography.Name = "radBiography";
            this.radBiography.Size = new System.Drawing.Size(72, 17);
            this.radBiography.TabIndex = 3;
            this.radBiography.TabStop = true;
            this.radBiography.Text = "Biography";
            this.radBiography.UseVisualStyleBackColor = true;
            // 
            // radMystery
            // 
            this.radMystery.AutoSize = true;
            this.radMystery.Location = new System.Drawing.Point(146, 19);
            this.radMystery.Name = "radMystery";
            this.radMystery.Size = new System.Drawing.Size(61, 17);
            this.radMystery.TabIndex = 2;
            this.radMystery.TabStop = true;
            this.radMystery.Text = "Mystery";
            this.radMystery.UseVisualStyleBackColor = true;
            // 
            // radNon
            // 
            this.radNon.AutoSize = true;
            this.radNon.Location = new System.Drawing.Point(15, 42);
            this.radNon.Name = "radNon";
            this.radNon.Size = new System.Drawing.Size(79, 17);
            this.radNon.TabIndex = 1;
            this.radNon.TabStop = true;
            this.radNon.Text = "Non-Fiction";
            this.radNon.UseVisualStyleBackColor = true;
            // 
            // radFiction
            // 
            this.radFiction.AutoSize = true;
            this.radFiction.Checked = true;
            this.radFiction.Location = new System.Drawing.Point(15, 19);
            this.radFiction.Name = "radFiction";
            this.radFiction.Size = new System.Drawing.Size(56, 17);
            this.radFiction.TabIndex = 0;
            this.radFiction.TabStop = true;
            this.radFiction.Text = "Fiction";
            this.radFiction.UseVisualStyleBackColor = true;
            // 
            // frmAddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 181);
            this.Controls.Add(this.grpGenre);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.txtISBN);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.lblGenre);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblISBN);
            this.Name = "frmAddBook";
            this.Text = "Add Book";
            this.grpGenre.ResumeLayout(false);
            this.grpGenre.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblGenre;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.GroupBox grpGenre;
        private System.Windows.Forms.RadioButton radBiography;
        private System.Windows.Forms.RadioButton radMystery;
        private System.Windows.Forms.RadioButton radNon;
        private System.Windows.Forms.RadioButton radFiction;
    }
}